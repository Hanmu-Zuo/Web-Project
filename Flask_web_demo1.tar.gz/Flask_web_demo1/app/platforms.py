#encoding: utf-8

from urllib2 import urlopen
from wand.image import Image
from app import webapp
import boto3
from decorators import login_required
from botocore.exceptions import ClientError
from flask import Flask, render_template, request, redirect, url_for, session
from boto3.dynamodb.conditions import Key,Attr
from salt_hash import Account
from werkzeug.security import check_password_hash
from werkzeug.security import generate_password_hash,check_password_hash
from werkzeug.utils import secure_filename
import uuid
import os
webapp.secret_key='\xf1\x92Y\xdf\x8ejY\x04\x96\xb4V\x88\xfb\xfc\xb5\x18F\xa3\xee\xb9\xb9t\x01\xf0\x96'
from time import *
ALLOWED_EXTENSIONS = set(['png', 'jpg', 'jpeg', 'gif'])
db3 = boto3.resource('dynamodb', region_name='us-east-1')
it=''
imglist=[]


@webapp.route('/create_table')
def create_table():
    db3 = boto3.resource('dynamodb', region_name='us-east-1')

    client = boto3.client('dynamodb')
    try:
        response = client.describe_table(TableName='User')
    except ClientError as ce:
        if ce.response['Error']['Code'] == 'ResourceNotFoundException':
            
            table = db3.create_table(
                TableName="User",
                KeySchema=[
                    {
                        'AttributeName': 'id',
                        'KeyType': 'HASH'  
                    }
                ],
                GlobalSecondaryIndexes=[
                    {
                        'IndexName': "SearchTelephone",
                        'KeySchema': [
                            {
                                'KeyType': 'HASH',
                                'AttributeName': 'telephone'
                            },
                        ],
                        'Projection': {
                            'ProjectionType': 'ALL',
                        },
                        'ProvisionedThroughput': {
                            'ReadCapacityUnits': 100,
                            'WriteCapacityUnits': 100
                        }
                    }
                ],

                AttributeDefinitions=[

                    {
                        'AttributeName': 'id',
                        'AttributeType': 'S'

                    },
                    {
                        'AttributeName': 'telephone',
                        'AttributeType': 'S'

                    }

                ],
                ProvisionedThroughput={
                    'ReadCapacityUnits': 100,
                    'WriteCapacityUnits': 100
                }
            )

            #table.meta.client.get_waiter('table_exists').wait(TableName='User')
            table = db3.create_table(
                TableName="Question",
                KeySchema=[
                    {
                        'AttributeName': 'id',
                        'KeyType': 'HASH' 
                    }#,
                    #{
                       # 'AttributeName': 'createtime',
                       # 'KeyType': 'RANGE'  
                    #}
                ],
                GlobalSecondaryIndexes=[
                    {
                        'IndexName': "SearchUser",
                        'KeySchema': [
                            {
                                'KeyType': 'HASH',
                                'AttributeName': 'user_id'
                            },
                            {
                                'AttributeName': 'id',
                                'KeyType': 'RANGE'  
                            }
                        ],
                        'Projection': {
                            'ProjectionType': 'ALL',
                        },
                        'ProvisionedThroughput': {
                            'ReadCapacityUnits': 100,
                            'WriteCapacityUnits': 100
                        }
                    },
                    {
                        'IndexName': "SearchTitle",
                        'KeySchema': [
                            {
                                'KeyType': 'HASH',
                                'AttributeName': 'title'
                            },
                            {
                                'KeyType': 'RANGE',
                                'AttributeName': 'createtime'
                            }
                            
                        ],
                        'Projection': {
                            'ProjectionType': 'ALL',
                        },
                        'ProvisionedThroughput': {
                            'ReadCapacityUnits': 100,
                            'WriteCapacityUnits': 100
                        }
                    }


                ],

                AttributeDefinitions=[

                    {
                        'AttributeName': 'id',
                        'AttributeType': 'S'

                    },
                    {
                        'AttributeName': 'user_id',
                        'AttributeType': 'S'

                    },
                    {
                        'AttributeName': 'createtime',
                        'AttributeType': 'S'

                    },
                    {
                        'AttributeName': 'title',
                        'AttributeType': 'S'

                    }


                ],
                ProvisionedThroughput={
                    'ReadCapacityUnits': 100,
                    'WriteCapacityUnits': 100
                }
            )

            
            return redirect(url_for('main'))
    else:
        return 'Tables Already Exist'


@webapp.route('/delete_table')
def delete_table():

    db3 = boto3.client('dynamodb', region_name='us-east-1')

    response = db3.delete_table(
        TableName='User'
    )
    response = db3.delete_table(
        TableName='Question'
    )
    return 'Delete Successfully!'

    


@webapp.route('/regist/', methods=['GET', 'POST'])
def regist():
    #return '1'
    db3 = boto3.resource('dynamodb', region_name='us-east-1')
    if request.method == 'GET':
        return render_template('regist.html')
    else:
        telephone = request.form.get('telephone')
        username = request.form.get('username')
        password1 = request.form.get('password1')
        password2 = request.form.get('password2')

        # 手机号码验证，如果被注册了就不能用了
        table = db3.Table('User')
        response = table.query(
            TableName='User',
            IndexName='SearchTelephone',
            KeyConditionExpression=Key('telephone').eq(telephone)
        )
        user = response['Items']

        if user != []:
            error_msg='The telephone has been registed'
            return render_template('regist.html',error_msg=error_msg)
        else:
            # password1 要和password2相等才可以
            if password1 != password2:
                error_msg='Please input the same password twice'
                return render_template('regist.html',error_msg=error_msg)
            else:
                headimage='https://s3.amazonaws.com/a1image/defaultheadimage.png'
                password1=generate_password_hash(password1)
                db3 = boto3.resource('dynamodb', region_name='us-east-1')
                table = db3.Table('User')
                id=str(uuid.uuid1())
                table.put_item(
                    Item = {
                        'id':id,
                        'username':username,
                        'password':password1,
                        'telephone':telephone,
                        'headimage':headimage,
                        'createtime':dateToStr(datetime.now()),
                        'collection_list':[]
                    }
                )

            
                # 如果注册成功，就让页面跳转到登录的页面
                
                return redirect(url_for('login'))
                

@webapp.route('/login/', methods=['GET', 'POST'])
def login():
     
     db3 = boto3.resource('dynamodb', region_name='us-east-1')
     if request.method == 'GET':
         return render_template('login.html')
     else:
         telephone = request.form.get('telephone')
         password = request.form.get('password')
         table = db3.Table('User')
         response = table.query(
            TableName='User',
            IndexName='SearchTelephone',
            KeyConditionExpression=Key('telephone').eq(telephone)
         )
         user = response['Items']
        
         if user!=[]:
             if check_password_hash(user[0]['password'],password):
                 session['user_id'] = user[0]['id']
                 # 如果想在31天内都不需要登录
                 session.permanent = True
                 user_id = session.get('user_id')
                 table = db3.Table('User')
                 response = table.query(
                    TableName='User',
                    IndexName='SearchTelephone',
                    KeyConditionExpression=Key('telephone').eq(telephone)
                 )
                 user = response['Items']
                 
                 if user!=[]:
                     imageurl = user[0]['headimage']
                     return redirect(url_for('index'))
             else:
                 error_msg="Wrong username or password"
                 return render_template('login.html',error_msg=error_msg)
         else:
             error_msg = "Wrong username or password"
             return render_template('login.html', error_msg=error_msg)
@webapp.route('/question/', methods=['GET', 'POST'])
@login_required
def question():
    db3 = boto3.resource('dynamodb', region_name='us-east-1')
    if request.method == 'GET':
        user_id = session.get('user_id')
        table = db3.Table('User')
        response = table.query(
           KeyConditionExpression=Key('id').eq(user_id)
        )
        user = response['Items']
        if user!=[]:
            imageurl = user[0]['headimage']
            return render_template('question.html',url=imageurl)
         
    else:
        #file = request.files['file']
        #user_id = session.get('user_id')
        #s3 = boto3.client('s3')
        #if file and allowed_file(file.filename):
            #with Image(file=file) as img:
                 #img.format='jpeg'
                 #pic=img.make_blob()
                 #s3=boto3.resource('s3')
                 #s3.Bucket('a1image').put_object(Key=session.get('user_id')+'/'+'{0}'.format(file.filename),Body=pic)
        #s3 = boto3.client('s3')
        #url = s3.generate_presigned_url(
            #ClientMethod='get_object',
            #Params=
            #{
                 #'Bucket': 'a1image',
                 #'Key': session.get('user_id')+'/'+'{0}'.format(file.filename)
            #}
        #)

        #imageurl = url.split('?')[0]
        #imagelist=[]
        #imagelist.append(imageurl)
        
        

        
        title = request.form.get('title')
        content = request.form.get('content')
        if not request.form.get('title'):
            title=' '
            
        if not request.form.get('content'):
            content=' '
        
        user_id = session.get('user_id')
        table = db3.Table('User')
        response = table.query(
           KeyConditionExpression=Key('id').eq(user_id)
        )
        user = response['Items']
        db3 = boto3.resource('dynamodb', region_name='us-east-1')
        session['questiontime'] =dateToStr(datetime.now())
        global imglist
        if imglist==[]:
            table = db3.Table('Question')
            id=str(uuid.uuid1())
            
        
            table.put_item(
                Item = {
                   'id':id,
                   'username':user[0]['username'],
                   'user_id':user[0]['id'],
                   'headimage':user[0]['headimage'],
                   'title':title,
                   'content':content,
                   'createtime':session['questiontime'],
                   'answers': [],
                   'questionimage':[]
               }
            ) 
            
        else:
            table = db3.Table('Question')
            id=str(uuid.uuid1())
            
        
            table.put_item(
                Item = {
                   'id':id,
                   'username':user[0]['username'],
                   'user_id':user[0]['id'],
                   'headimage':user[0]['headimage'],
                   'title':title,
                   'content':content,
                   'createtime':session['questiontime'],
                   'answers': [],
                   'questionimage':imglist
               }
            ) 
            
            imglist=[]
            
        #table = db3.Table('Question')
        #response = table.query(
           #IndexName='SearchUser',
           #KeyConditionExpression=Key('user_id').eq(user_id)&Key('id').eq(id)
        #)
        
        return redirect(url_for('index'))



@webapp.route('/')

def index():
    #session['qid']=[]
    #return render_template('loading.html')
    #return render_template('i2.html')
    db3 = boto3.resource('dynamodb', region_name='us-east-1')
    table = db3.Table('Question')
    records=[]
    sortrecords=[]
    
  
    response = table.scan(TableName='Question')
    for i in response['Items']:
        records.append(i)
    while 'LastEvaluatedKey' in response:
        response = table.scan(
            ExclusiveStartKey=response['LastEvaluatedKey']
            )

        for i in response['Items']:
            records.append(i)
    
    for j in range(len(records)):
        minindex=0
        mintime=records[0]['createtime']
    	for i in range(len(records)):
            if cmp(mintime,records[i]['createtime'])<0:
                mintime=records[i]['createtime']
                minindex=i
        sortrecords.append(records[minindex])
        del records[minindex]
   





    context = {
        'questions': sortrecords
    }
    if session.get('user_id')!=None:
        user_id = session.get('user_id')
        table = db3.Table('User')
        response = table.query(
           KeyConditionExpression=Key('id').eq(user_id)
        )
        user = response['Items']
        if user!=[]:
            imageurl = user[0]['headimage']
            return render_template('index.html',url=imageurl, **context)

    else:
        return render_template('index.html', **context)
    
    return render_template('index.html', **context)
@webapp.route('/detail/<question_id>/')
def detail(question_id):
    db3 = boto3.resource('dynamodb', region_name='us-east-1')
    table = db3.Table('Question')
    response = table.query(
        KeyConditionExpression=Key('id').eq(question_id)
    )
    question_model=response['Items']
    
    i = 0
    if question_model[0]['answers']==[]:
        i=0
    else:
        for answers in question_model[0]['answers']:
            i = i + 1
    if session.get('user_id')!=None:
        user_id = session.get('user_id')
   
    	table = db3.Table('User')
    	response = table.query(
       		KeyConditionExpression=Key('id').eq(user_id)
    	)
    	user = response['Items']
    	if user!=[]:
            imageurl = user[0]['headimage']
            return render_template('detail.html', url=imageurl, question=question_model, i=i)
    else:
        return render_template('detail.html', question=question_model, i=i)
@webapp.route('/collection/', methods=['GET', 'POST'])
def collection():
    db3 = boto3.resource('dynamodb', region_name='us-east-1')
    user_id = session['user_id']
    
    table = db3.Table('User')
    response = table.query(
       KeyConditionExpression=Key('id').eq(user_id)
    )
    user = response['Items']
    records=[]
    for collection_id in user[0]['collection_list']:
    ############
        db3 = boto3.resource('dynamodb', region_name='us-east-1')
        table = db3.Table('Question')
        
        response = table.scan(FilterExpression=Attr("id").eq(collection_id))
        for i in response['Items']:
            records.append(i)
    sortrecords=[]
    for j in range(len(records)):
        minindex=0
        mintime=records[0]['createtime']
    	for i in range(len(records)):
            if cmp(mintime,records[i]['createtime'])<0:
                mintime=records[i]['createtime']
                minindex=i
        sortrecords.append(records[minindex])
        del records[minindex]
    context = {
        'questions': sortrecords
    }
    if session.get('user_id')!=None:
        user_id = session.get('user_id')
        table = db3.Table('User')
        response = table.query(
           KeyConditionExpression=Key('id').eq(user_id)
        )
        user = response['Items']
        if user!=[]:
            imageurl = user[0]['headimage']
            return render_template('index.html',url=imageurl, **context)

    else:
        return render_template('index.html', **context)
    
    return render_template('index.html', **context)
    
@webapp.route('/collect/', methods=['GET', 'POST'])
def collect():
    collection_new=request.form.getlist('questionid')
    db3 = boto3.resource('dynamodb', region_name='us-east-1')
    
    table = db3.Table('User')
    response = table.update_item(
    Key={
        "id":session.get('user_id')
       
    },
    
    UpdateExpression="set collection_list = :i",
    ExpressionAttributeValues={
        ":i": collection_new
             },
    ReturnValues ="UPDATED_NEW"
    )
    return redirect(url_for('index'))
@webapp.route('/add_answer/', methods=['POST'])
@login_required
def add_answer():
    db3 = boto3.resource('dynamodb', region_name='us-east-1')
    content = request.form.get('answer_content')
    question_id = request.form.get('question_id')
    
    user_id = session.get('user_id')
    table = db3.Table('User')
    response = table.query(
       KeyConditionExpression=Key('id').eq(user_id)
    )
    user = response['Items']
    table = db3.Table('Question')
    session['answertime']=dateToStr(datetime.now())
    response = table.update_item(
    Key={
        "id":question_id
       
    },
    
    UpdateExpression="set answers = list_append(answers, :i)",
    ExpressionAttributeValues={
        ":i": [{
                'username':user[0]['username'],
                'headimage':user[0]['headimage'],
                'createtime':session['answertime'],
                'content':content,
                'id':str(uuid.uuid1()),
                'user_id':user_id
               }
              ]
             },
    ReturnValues ="UPDATED_NEW"
    )

 
    user_id = session['user_id']
    
    table = db3.Table('User')
    response = table.query(
       KeyConditionExpression=Key('id').eq(user_id)
    )
    user = response['Items']

    
    if user!=[]:
        imageurl = user[0]['headimage']
        return redirect(url_for('detail', url=imageurl,question_id=question_id))

@webapp.route('/search/')
#@login_required
def search():
    db3 = boto3.resource('dynamodb', region_name='us-east-1')
    q = request.args.get('q')
    if q!='':
     
        questions=[]
        sortquestions=[]
        table = db3.Table('Question')
        response = table.scan(
        
           FilterExpression=Attr("title").contains(q) | Attr("content").contains(q),
        )
        while 'LastEvaluatedKey' in response:
            response = table.scan(
               ExclusiveStartKey=response['LastEvaluatedKey']
               )

            for i in response['Items']:
                questions.append(i)
        for i in response['Items']:
            questions.append(i)
        for j in range(len(questions)):
            minindex=0
            mintime=questions[0]['createtime']
    	    for i in range(len(questions)):
                if cmp(mintime,questions[i]['createtime'])<0:
                    mintime=questions[i]['createtime']
                    minindex=i
            sortquestions.append(questions[minindex])
            del questions[minindex]
        if session.get('user_id')!=None:
            user_id = session.get('user_id')
            table = db3.Table('User')
            response = table.query(
               KeyConditionExpression=Key('id').eq(user_id),
        
            )
     
            user = response['Items']



            if user!=[]:
                imageurl = user[0]['headimage']
     
                return render_template('index.html',url=imageurl,questions=sortquestions)
	else:
            return render_template('index.html',questions=sortquestions)
    else:
        if session.get('user_id')!=None:
             user_id = session.get('user_id')
             table = db3.Table('User')
             response = table.query(
                KeyConditionExpression=Key('id').eq(user_id),
        
             )
     
             user = response['Items']



             if user!=[]:
                 imageurl = user[0]['headimage']
    
                 return render_template('index.html',url=imageurl)
	else:
             return render_template('index.html')
     
@webapp.route('/search/')
#@login_required
def searchtag(q):
     db3 = boto3.resource('dynamodb', region_name='us-east-1')
     
    
     
     questions=[]
     sortquestions=[]
     table = db3.Table('Question')
     response = table.scan(
        
        FilterExpression=Attr("title").contains(q) | Attr("content").contains(q),
     )
     while 'LastEvaluatedKey' in response:
        response = table.scan(
            ExclusiveStartKey=response['LastEvaluatedKey']
            )

        for i in response['Items']:
            questions.append(i)
     for i in response['Items']:
        questions.append(i)
     for j in range(len(questions)):
        minindex=0
        mintime=questions[0]['createtime']
    	for i in range(len(questions)):
            if cmp(mintime,questions[i]['createtime'])<0:
                mintime=questions[i]['createtime']
                minindex=i
        sortquestions.append(questions[minindex])
        del questions[minindex]
     if session.get('user_id')!=None:
         user_id = session.get('user_id')
         table = db3.Table('User')
         response = table.query(
            KeyConditionExpression=Key('id').eq(user_id),
        
         )
     
         user = response['Items']



         if user!=[]:
             imageurl = user[0]['headimage']
     
             return render_template('index.html',url=imageurl,questions=sortquestions)
     else:
         return render_template('index.html',questions=sortquestions)

@webapp.route('/questionimg/', methods=['GET', 'POST'])
def questionimg():
    #return 200
    i=''
    #global it
    #if request.method =='POST':
     
        #for IMG in request.files.getlist('fileAttach'):
            #it = it+IMG.filename 
        #return it
    #if request.method =='GET':
        #return it

    
    global imglist
    
    if request.method =='POST':
        
        for IMG in request.files.getlist('fileAttach'):
            s3 = boto3.client('s3')
            if IMG and allowed_file(IMG.filename):
             
                with Image(file=IMG) as img:
                    img.format='jpeg'
                    pic=img.make_blob()
                    s3=boto3.resource('s3')
                    s3.Bucket('a1image').put_object(Key=session.get('user_id')+'/'+'{0}'.format(IMG.filename),Body=pic)
            s3 = boto3.client('s3')
            url = s3.generate_presigned_url(
                ClientMethod='get_object',
                Params=
                {
                 'Bucket': 'a1image',
                 'Key': session.get('user_id')+'/'+'{0}'.format(IMG.filename)
                }
            )

            imageurl = url.split('?')[0]       
            imglist.append(imageurl)
        
    return '{}',200 


@webapp.route('/userinformation/', methods=['GET', 'POST'])
@webapp.route('/userInformation/', methods=['GET', 'POST'])
def userinformation():
     #global it
     #if request.method =='POST':
     
         #for img in request.files.getlist('fileAttach'):
             #it = it+'1'
         #return it
     #if request.method =='GET':
         #return it

    db3 = boto3.resource('dynamodb', region_name='us-east-1')
    if request.method =='GET':
        user_id = session.get('user_id')
        table = db3.Table('User')
        response1 = table.query(
           KeyConditionExpression=Key('id').eq(user_id)
        )
        user = response1['Items']
         




        questions=[]
        sortquestions=[]
        table = db3.Table('Question')
        response = table.scan(
         
           FilterExpression=Attr("user_id").eq(user_id)
        )
        for i in response['Items']:
            questions.append(i)
        while 'LastEvaluatedKey' in response:
            response = table.scan(
                ExclusiveStartKey=response['LastEvaluatedKey']
            )

         
            for i in response['Items']:
               questions.append(i)
        for j in range(len(questions)):
            minindex=0
            mintime=questions[0]['createtime']
    	    for i in range(len(questions)):
                if cmp(mintime,questions[i]['createtime'])<0:
                    mintime=questions[i]['createtime']
                    minindex=i
            sortquestions.append(questions[minindex])
            del questions[minindex]
         #return sortquestions[0]['title']









         
        if user!=[]:
            imageurl = user[0]['headimage']
        return render_template("userinformation.html",url=imageurl,user_questions=sortquestions)
    else:
	if 'file' not in request.files:
            return redirect(url_for('userinformation'))
        file = request.files['file']
        if file.filename=='':
            return redirect(url_for('userinformation'))

        s3 = boto3.client('s3')
        if file and allowed_file(file.filename):
             
            with Image(file=file) as img:
                img.sample(250,250)
                img.format='jpeg'
                pic=img.make_blob()
                s3=boto3.resource('s3')
                s3.Bucket('a1image').put_object(Key=session.get('user_id')+'/'+'{0}'.format(file.filename),Body=pic)
        s3 = boto3.client('s3')
        url = s3.generate_presigned_url(
            ClientMethod='get_object',
            Params=
            {
                'Bucket': 'a1image',
                'Key': session.get('user_id')+'/'+'{0}'.format(file.filename)
            }
        )

        imageurl = url.split('?')[0]
        user_id = session.get('user_id')
        table = db3.Table('User')
        response = table.update_item(
           Key={
           "id":user_id
        },
        UpdateExpression="set headimage = :r",
        ExpressionAttributeValues={
            ":r":imageurl
            },
        ReturnValues ="UPDATED_NEW"
        )

         ###############################
        table = db3.Table('Question')
        records=[]
        response = table.scan(TableName='Question')
        for i in response['Items']:
            records.append(i)
        while 'LastEvaluatedKey' in response:
            response = table.scan(
            ExclusiveStartKey=response['LastEvaluatedKey']
            )

            for i in response['Items']:
                records.append(i)

        for qi in records:
            if(qi['user_id']==user_id):
                table = db3.Table('Question')
                response = table.update_item(
                    Key={
                    #"user_id":user_id,
                    "id":qi['id']
                },
                #IndexName='SearchUser',
                UpdateExpression="set headimage = :r",
                ExpressionAttributeValues={
                    ":r":imageurl
                },
                ReturnValues ="UPDATED_NEW"
                )  
             #for ai in qi['answers']:
            for ai in range(len(qi['answers'])):
               #if (ai['user_id']==user_id):
                if qi['answers'][ai]['user_id']==user_id:
                    table = db3.Table('Question')
                    response = table.update_item(
                       Key={
                       #"user_id":user_id,
                       "id":qi['id']
                    },
                     #IndexName='SearchUser',
                    UpdateExpression="set answers[{}].headimage = :r".format(ai),
                    ExpressionAttributeValues={
                        #":q":ai,
                        ":r":imageurl
                    },
                    ReturnValues ="UPDATED_NEW"
                    )  
                     
        
         
        



         ###########################################3
	#return '11112'
	table = db3.Table('User')
        response1 = table.query(
            KeyConditionExpression=Key('id').eq(user_id)
        )
        user = response1['Items']
         
        #return user[0]['telephone']
        questions=[]
        sortquestions=[]
        table = db3.Table('Question')
        response = table.scan(
        
           FilterExpression=Attr("user_id").eq(user_id)
        )
        for i in response['Items']:
            questions.append(i)
        while 'LastEvaluatedKey' in response:
            response = table.scan(
            ExclusiveStartKey=response['LastEvaluatedKey']
            )

            for i in response['Items']:
                questions.append(i)
        
        #return questions[0]['title']
        if questions:
            for j in range(len(questions)):
                minindex=0
                mintime=questions[0]['createtime']
    	        for i in range(len(questions)):
                    if cmp(mintime,questions[i]['createtime'])<0:
                        mintime=questions[i]['createtime']
                        minindex=i
                sortquestions.append(questions[minindex])
                del questions[minindex]
         
         #return user_questions[0]
            if user!=[]:
                imageurl = user[0]['headimage']
            return render_template("userinformation.html", url=imageurl,user_questions=sortquestions)
        else:
            if user!=[]:
                imageurl = user[0]['headimage']
            return render_template("userinformation.html", url=imageurl)
@webapp.route('/delete/<question_id>/', methods=['POST','GET'])
def delete(question_id):
    user_id = session.get('user_id')
    db3 = boto3.resource('dynamodb', region_name='us-east-1')
    table=db3.Table('Question')
    table.delete_item(
        Key={
             'id': question_id
             }
    ) 
    table = db3.Table('User')
    
    response1 = table.query(
         KeyConditionExpression=Key('id').eq(user_id)
    )
    user = response1['Items']
         

    questions=[]
    sortquestions=[]
    table = db3.Table('Question')
    response = table.scan(
        
        FilterExpression=Attr("user_id").eq(user_id)
    )
    for i in response['Items']:
        questions.append(i)
    while 'LastEvaluatedKey' in response:
        response = table.scan(
            ExclusiveStartKey=response['LastEvaluatedKey']
        )

    
        for i in response['Items']:
            questions.append(i)
    if question:
        for j in range(len(questions)):
            minindex=0
            mintime=questions[0]['createtime']
            for i in range(len(questions)):
                if cmp(mintime,questions[i]['createtime'])<0:
                    mintime=questions[i]['createtime']
                    minindex=i
            sortquestions.append(questions[minindex])
            del questions[minindex]
         
        if user!=[]:
            imageurl = user[0]['headimage']
        return render_template("userinformation.html", url=imageurl,user_questions=sortquestions)
    else:
        if user!=[]:
            imageurl = user[0]['headimage']
        return render_template("userinformation.html", url=imageurl)
    




def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1] in ALLOWED_EXTENSIONS

@webapp.route('/logout/')
def logout():
     session.clear()
     return redirect(url_for('login'))

@webapp.context_processor
def my_context_processor():
     db3 = boto3.resource('dynamodb', region_name='us-east-1')
     user_id = session.get('user_id')
     if user_id:
         table = db3.Table('User')
         response = table.query(
             KeyConditionExpression=Key('id').eq(user_id)
         )
         user = response['Items']
         #user = User.query.filter(User.id == user_id).first()
         if user:
             return {'user': user}
     return {}

@webapp.route('/changepassword/',methods=['POST','GET'])
def changepassword():
    db3 = boto3.resource('dynamodb', region_name='us-east-1')
    if request.method == 'GET':
        return render_template('changepassword.html')
    if request.method == 'POST':
        password1 = request.form.get('password1')
        password2 = request.form.get('password2')
        if password1 != password2:
            error_msg='Please input the same password twice'
            return render_template('changepassword.html',error_msg=error_msg)
        else:
            headimage='https://s3.amazonaws.com/a1image/defaultheadimage.png'
            password1=generate_password_hash(password1)
            db3 = boto3.resource('dynamodb', region_name='us-east-1')
                
            user_id = session.get('user_id')
            table = db3.Table('User')
            response = table.update_item(
            Key={
            "id":user_id
            },
            UpdateExpression="set password = :r",
            ExpressionAttributeValues={
            ":r":password1
            },
            ReturnValues ="UPDATED_NEW"
            )
            
            # 如果注册成功，就让页面跳转到登录的页面
            return redirect(url_for('index'))
       
    
