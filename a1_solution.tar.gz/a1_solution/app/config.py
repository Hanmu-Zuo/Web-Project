db_config = {'user': 'ece1779',
             'password': 'secret',
             'host': '127.0.0.1',
             'database': 'photos'}

